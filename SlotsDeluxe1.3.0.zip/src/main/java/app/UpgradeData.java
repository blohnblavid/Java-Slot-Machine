package app;

public class UpgradeData {

    private final Model model;
    private final AchievementManager achievementManager;
    private final AchievementsView achievementsView;

    // Base prices
    private static final int BASE_REEL_COST = 1000;
    private static final int BASE_ROW_COST = 200000;

    public UpgradeData(Model model,
                       AchievementManager achievementManager,
                       AchievementsView achievementsView) {

        this.model = model;
        this.achievementManager = achievementManager;
        this.achievementsView = achievementsView;
    }

    // ----------------------------
    //   PRICING FORMULAS
    // ----------------------------
    public int getNextReelCost() {
        int current = model.getReelCount();
        return BASE_REEL_COST * current;
    }

    public int getNextRowCost() {
        int current = model.getRowCount();
        return BASE_ROW_COST * current;
    }

    // ----------------------------
    //      BUY UPGRADES
    // ----------------------------
    public boolean buyReel() {
        int cost = getNextReelCost();
        if (model.getBalance() < cost) return false;
        if (model.getReelCount() >= 12) return false;

        model.adjustCredits(-cost);
        model.addReel();

        // ACHIEVEMENT — FIRST REEL
        achievementManager.unlock("first_reel");
        achievementsView.refresh();

        return true;
    }

    public boolean buyRow() {
        int cost = getNextRowCost();
        if (model.getBalance() < cost) return false;
        if (model.getRowCount() >= 4) return false;

        model.adjustCredits(-cost);
        model.addRow();

        // ACHIEVEMENT — FOURTH ROW = GAME COMPLETED
        if (model.getRowCount() == 4) {
            achievementManager.unlock("fourth_row");
            achievementsView.refresh();
        }

        return true;
    }
}
