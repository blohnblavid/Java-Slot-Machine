package app;

import app.themes.Theme;   // <-- new import
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.Scene;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.net.URL;
import java.util.*;

public class SkinManager {

    // -------------------------
    // Skin WITH Theme support
    // -------------------------
    public static class Skin {
        public final String id;
        public final String displayName;
        public final int price;
        public final String cssResource;
        public Theme themeObject;   // <-- NEW (optional)

        public Skin(String id, String name, int price, String cssResource) {
            this.id = id;
            this.displayName = name;
            this.price = price;
            this.cssResource = cssResource;
            this.themeObject = null;
        }
    }

    private final List<Skin> skins = new ArrayList<>();
    private final Set<String> owned = new HashSet<>();
    private Skin current;

    private Timeline rainbowAnim;
    private Timeline sweepAnim;
    private Rectangle sweepRect;

    public SkinManager() {

        // Existing skins
        skins.add(new Skin("classic", "Classic", 0, "/styles/classic.css"));
        skins.add(new Skin("emerald", "Emerald", 500, "/styles/emerald.css"));
        skins.add(new Skin("royal", "Royal Gold", 1500, "/styles/royal.css"));
        skins.add(new Skin("rainbow", "Rainbow Dream", 5000, "/styles/rainbow.css"));

        // Example: attach your theme here
        // skins.get(0).themeObject = new ClassicCasinoTheme();

        current = skins.get(0);
        owned.add(current.id);
    }

    public List<Skin> all() { return skins; }
    public boolean isOwned(String id) { return owned.contains(id); }
    public Skin current() { return current; }
    public void acquire(String id) { owned.add(id); }

    public boolean equip(String id) {
        for (Skin s : skins) {
            if (s.id.equals(id) && owned.contains(id)) {
                current = s;
                return true;
            }
        }
        return false;
    }

    public void apply(Scene scene) {

        // Reset styles
        scene.getStylesheets().clear();
        if (current == null) return;

        // Load CSS
        URL url = getClass().getResource(current.cssResource);
        if (url != null)
            scene.getStylesheets().add(url.toExternalForm());

        // Clear animations
        if (rainbowAnim != null) { rainbowAnim.stop(); rainbowAnim = null; }
        if (sweepAnim != null)   { sweepAnim.stop();   sweepAnim   = null; }

        if (scene.getRoot() != null)
            scene.getRoot().setEffect(null);

        if (sweepRect != null && scene.getRoot() instanceof StackPane spOld) {
            spOld.getChildren().remove(sweepRect);
            sweepRect = null;
        }

        // ----------------------------
        // APPLY THEME if attached
        // ----------------------------
        if (current.themeObject != null) {
            Theme t = current.themeObject;

            // Background
            if (scene.getRoot() != null) {
                String style = "-fx-background-image: url('" + t.backgroundImage() + "');" +
                        "-fx-background-size: cover;";
                scene.getRoot().setStyle(style);
            }
        }

        // ----------------------------
        // Rainbow special effect
        // ----------------------------
        if ("rainbow".equals(current.id)) {
            ColorAdjust hue = new ColorAdjust();
            hue.setHue(-1.0);
            scene.getRoot().setEffect(hue);

            rainbowAnim = new Timeline(
                    new KeyFrame(Duration.ZERO,       new KeyValue(hue.hueProperty(), -1.0)),
                    new KeyFrame(Duration.seconds(6), new KeyValue(hue.hueProperty(),  1.0))
            );
            rainbowAnim.setAutoReverse(true);
            rainbowAnim.setCycleCount(Animation.INDEFINITE);
            rainbowAnim.play();
        }

    }
}
