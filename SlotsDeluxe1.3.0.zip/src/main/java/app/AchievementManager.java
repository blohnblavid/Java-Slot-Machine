package app;

import java.util.ArrayList;
import java.util.List;

public class AchievementManager {

    private final List<Achievement> list = new ArrayList<>();

    public AchievementManager() {

        list.add(new Achievement(
                "first_spin",
                "First Spin!",
                "Win your first spin.",
                "/achievements/firstspin.png"
        ));

        list.add(new Achievement(
                "first_reel",
                "More Slots!",
                "Buy your first reel.",
                "/achievements/firstreel.png"
        ));

        list.add(new Achievement(
                "first_theme",
                "New Look!",
                "Buy your first theme.",
                "/achievements/firsttheme.png"
        ));

        list.add(new Achievement(
                "big_win",
                "Big Winner!",
                "Win over 1,000 credits in one spin.",
                "/achievements/bigwin1.png"
        ));

        list.add(new Achievement(
                "rainbow_theme",
                "It's like a dream!",
                "Buy the Rainbow Dream theme.",
                "/achievements/rainbow.png"
        ));

        list.add(new Achievement(
                "huge_win",
                "Huge Jackpot!!",
                "Win over 10,000 credits in one spin.",
                "/achievements/bigwin2.png"
        ));

        list.add(new Achievement(
                "mega_win",
                "MEGA Jackpot!!!",
                "Win over 50,000 credits in one spin.",
                "/achievements/bigwin3.png"
        ));

        list.add(new Achievement(
                "millionaire",
                "Millionaire!",
                "Have over 1,000,000 credits.",
                "/achievements/millionaire.png"
        ));

        list.add(new Achievement(
                "fourth_row",
                "Break the machine",
                "Buy the fourth row and beat the game",
                "/achievements/fourthrow.png"
        ));
    }

    public List<Achievement> all() {
        return list;
    }

    public Achievement get(String id) {
        for (Achievement a : list)
            if (a.id.equals(id))
                return a;
        return null;
    }

    public void unlock(String id) {
        Achievement a = get(id);
        if (a != null) a.unlock();
    }
}
