package app;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Main extends Application {

    private final AchievementManager achievementManager = new AchievementManager();
    private final Model model = new Model();
    private final SkinManager skinManager = new SkinManager();
    private final StatsManager stats = new StatsManager();

    @Override
    public void start(Stage stage) {
        try { Font.loadFont(getClass().getResourceAsStream("/fonts/SHOWG.TTF"), 24); } catch (Exception ignored) {}

        BorderPane appRoot = new BorderPane();
        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        AchievementsView achievementsView = new AchievementsView(achievementManager);
        GameView game = new GameView(model, skinManager, stats, achievementManager, achievementsView);
        UpgradeData upgradeData = new UpgradeData(model, achievementManager, achievementsView);
        ShopView shop = new ShopView(model, skinManager, stats, game, upgradeData, achievementManager, achievementsView);

        Tab gameTab = new Tab("Game", game.getRoot());
        Tab shopTab = new Tab("Shop", shop.getRoot());
        Tab achTab = new Tab("Achievements", achievementsView.getRoot());
        tabs.getTabs().addAll(gameTab, shopTab, achTab);
        appRoot.setCenter(tabs);

        StackPane container = new StackPane(appRoot);
        // This method chooses the targets base resolution
        int targetWidth = 1920;
        int targetHeight = 1080;

        Scene scene = new Scene(container, targetWidth, targetHeight);
        stage.setWidth(targetWidth);
        stage.setHeight(targetHeight);

// This method prevents the window from being resized
        stage.setResizable(false);
        skinManager.apply(scene);
        stage.setTitle("Slots Deluxe");
        stage.setScene(scene);

        stage.setOnCloseRequest(ev -> {
            ev.consume();
            new StatsView(stats).showAndExit(stage);
        });

        stage.show();

        model.setOnBalanceChanged(() -> {
            game.refreshBalance();
            shop.refreshBalance();
        });
        shop.setOnSkinEquipped(game::refreshSkin);
    }

    public static void main(String[] args) { launch(); }
}