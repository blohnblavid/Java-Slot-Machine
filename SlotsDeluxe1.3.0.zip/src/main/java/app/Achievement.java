package app;

public class Achievement {

    public final String id;
    public final String title;
    public final String description;
    public final String imagePath;  // NEW: path to icon

    private boolean unlocked = false;

    public Achievement(String id, String title, String description, String imagePath) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.imagePath = imagePath;
    }

    public boolean isUnlocked() {
        return unlocked;
    }

    public void unlock() {
        unlocked = true;
    }
}
