package app;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Model {

    private static final int MAX_ROWS = 4;
    private static final int MAX_REELS = 12;
    public static int getMaxRows() { return MAX_ROWS; }
    public static int getMaxReels() { return MAX_REELS; }

    // -----------------------------
    //   SYMBOL + BANK
    // -----------------------------
    public static class Symbol {
        public final String name;
        public final String imagePath;
        public final int weight;
        public final int payout3;


        public Symbol(String name, String imagePath, int weight, int payout3) {
            this.name = name;
            this.imagePath = imagePath;
            this.weight = weight;
            this.payout3 = payout3;
        }
    }

    private static class Reel {
        private final List<Symbol> bucket = new ArrayList<>();
        private final Random rng;


        Reel(List<Symbol> symbols, Random rng) {
            this.rng = rng;
            for (Symbol s : symbols) {
                for (int i = 0; i < s.weight; i++) {
                    bucket.add(s);
                }
            }
        }

        Symbol spin() {
            int idx = rng.nextInt(bucket.size());
            return bucket.get(idx);
        }
    }

    public static class Bank {
        public int credits;

        Bank(int start) {
            credits = start;
        }

        public boolean canBet(int bet) {
            return bet > 0 && credits >= bet;
        }

        public void applyBet(int bet) {
            credits -= bet;
        }

        public void applyWin(int win) {
            credits += win;
        }
    }

    // -----------------------------
    //   MODEL STATE
    // -----------------------------
    public final List<Symbol> symbols = List.of(
            new Symbol("cherry", "/images/cherry.png", 40, 5),
            new Symbol("lemon", "/images/lemon.png", 30, 10),
            new Symbol("bell", "/images/bell.png", 20, 20),
            new Symbol("diamond", "/images/diamond.png", 8, 50),
            new Symbol("seven", "/images/seven.png", 2, 100)
    );

    private final Random rng = new SecureRandom();
    private final List<Reel> reels = new ArrayList<>();

    private int reelCount = 3;
    private int rowCount = 3;

    public final Bank bank = new Bank(500);
    public final List<Symbol> outcome = new ArrayList<>();

    private Runnable onBalanceChanged = () -> {};

    public Model() {
        // initialize starting reels
        for (int i = 0; i < reelCount; i++) {
            reels.add(new Reel(symbols, rng));
        }
    }

    public int getReelCount() {
        return reelCount;
    }

    public int getRowCount() {
        return rowCount;
    }

    public void addReel() {
        if (reelCount < MAX_REELS) {
            reelCount++;
            reels.add(new Reel(symbols, rng));
        }
    }

    public void addRow() {
        if (rowCount < MAX_ROWS) {
            rowCount++;
        }
    }

    public void setOnBalanceChanged(Runnable r) {
        this.onBalanceChanged = (r != null ? r : () -> {});
    }

    public int getBalance() {
        return bank.credits;
    }

    public void adjustCredits(int delta) {
        bank.credits += delta;
        if (bank.credits < 0) bank.credits = 0;
        onBalanceChanged.run();
    }

    public void resetBalance(int to) {
        bank.credits = Math.max(0, to);
        onBalanceChanged.run();
    }

    public SpinResult spin(int bet) {
        if (!bank.canBet(bet)) {
            return new SpinResult(false, 0, List.of());
        }

        bank.applyBet(bet);

        outcome.clear();
        for (int r = 0; r < rowCount; r++) {
            for (int c = 0; c < reelCount; c++) {
                Symbol s = reels.get(c).spin();
                outcome.add(s);
            }
        }

        int win = computeWin(outcome, rowCount, reelCount, bet);
        if (win > 0) bank.applyWin(win);

        onBalanceChanged.run();
        return new SpinResult(true, win, List.copyOf(outcome));
    }

    /**
     * Computes total win for the current grid.
     * Rule (Tier 1+): ANY 3 matching symbols in a row horizontally
     * or diagonally (down-right or up-right), on ANY grid size.
     */
    private int computeWin(List<Symbol> grid, int rows, int cols, int bet) {
        int totalWin = 0;

        // helper to index into 1D list as if 2D [r][c]
        java.util.function.BiFunction<Integer, Integer, Symbol> at = (r, c) ->
                grid.get(r * cols + c);

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                Symbol s0 = at.apply(r, c);

                // skip if null (shouldn't happen) just in case
                if (s0 == null) continue;

                // --- horizontal (to the right) ---
                if (c + 2 < cols) {
                    Symbol s1 = at.apply(r, c + 1);
                    Symbol s2 = at.apply(r, c + 2);
                    if (sameName(s0, s1, s2)) {
                        totalWin += bet * s0.payout3;
                    }
                }

                // --- diagonal down-right ---
                if (r + 2 < rows && c + 2 < cols) {
                    Symbol s1 = at.apply(r + 1, c + 1);
                    Symbol s2 = at.apply(r + 2, c + 2);
                    if (sameName(s0, s1, s2)) {
                        totalWin += bet * s0.payout3;
                    }
                }

                // --- diagonal up-right ---
                if (r - 2 >= 0 && c + 2 < cols) {
                    Symbol s1 = at.apply(r - 1, c + 1);
                    Symbol s2 = at.apply(r - 2, c + 2);
                    if (sameName(s0, s1, s2)) {
                        totalWin += bet * s0.payout3;
                    }
                }
            }
        }

        return totalWin;
    }

    private boolean sameName(Symbol a, Symbol b, Symbol c) {
        return a != null && b != null && c != null &&
                a.name.equals(b.name) &&
                b.name.equals(c.name);
    }

    public record SpinResult(boolean accepted, int win, List<Symbol> symbols) {}
}
