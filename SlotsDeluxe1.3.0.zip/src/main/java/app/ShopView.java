package app;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class ShopView {

    private final Model model;
    private final SkinManager skinManager;
    private final StatsManager stats;
    private final GameView game;
    private final UpgradeData upgradeData;
    private final AchievementManager achievementManager;
    private final AchievementsView achievementsView;

    private final BorderPane root = new BorderPane();
    private final Label balance = new Label();
    private final VBox list = new VBox(10);

    private Runnable onSkinEquipped = () -> {};

    @FunctionalInterface
    private interface BoolSupplier {
        boolean run();
    }

    public ShopView(Model model,
                    SkinManager skinManager,
                    StatsManager stats,
                    GameView game,
                    UpgradeData upgradeData,
                    AchievementManager achievementManager,
                    AchievementsView achievementsView) {

        this.model = model;
        this.skinManager = skinManager;
        this.stats = stats;
        this.game = game;
        this.upgradeData = upgradeData;
        this.achievementManager = achievementManager;
        this.achievementsView = achievementsView;

        build();
        refreshBalance();
        refreshList();
    }

    private void build() {
        root.getStyleClass().add("shop-root");

        VBox top = new VBox(6);
        top.setPadding(new Insets(16));
        top.setAlignment(Pos.CENTER);

        Label title = new Label("SHOP");
        title.getStyleClass().add("title");

        balance.getStyleClass().add("balance");
        top.getChildren().addAll(title, balance);

        list.setPadding(new Insets(16));

        root.setTop(top);
        root.setCenter(list);
    }

    private Node skinRow(SkinManager.Skin s) {
        HBox row = new HBox(12);
        row.getStyleClass().add("card");
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(12));

        Label name = new Label(s.displayName);
        name.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label price = new Label(s.price == 0 ? "FREE" : (s.price + " cr"));
        price.setStyle("-fx-opacity: 0.85;");

        Label status = new Label();
        Button action = new Button();

        boolean owned = skinManager.isOwned(s.id);
        boolean equipped = skinManager.current() != null &&
                skinManager.current().id.equals(s.id);

        if (equipped) {
            status.setText("Equipped");
            action.setDisable(true);
            action.setText("Equipped");
        }
        else if (owned) {
            status.setText("Owned");
            action.setText("Equip");

            action.setOnAction(e -> {
                if (skinManager.equip(s.id)) {
                    onSkinEquipped.run();
                    refreshList();
                }
            });
        }
        else {
            status.setText("Locked");
            action.setText("Buy");

            action.setOnAction(e -> {
                if (model.getBalance() >= s.price) {

                    model.adjustCredits(-s.price);
                    skinManager.acquire(s.id);

                    if (stats != null)
                        stats.recordPurchase(s.price);

                    // ACHIEVEMENTS
                    achievementManager.unlock("first_theme");

                    if ("rainbow".equals(s.id))
                        achievementManager.unlock("rainbow_theme");

                    achievementsView.refresh();

                    refreshBalance();
                    refreshList();
                }
            });
        }

        HBox spacer = new HBox();
        spacer.setPrefWidth(20);
        HBox.setHgrow(spacer, javafx.scene.layout.Priority.ALWAYS);

        row.getChildren().addAll(name, price, spacer, status, action);
        return row;
    }

    private Node upgradeRow(String title, String priceText, BoolSupplier onBuy) {
        HBox row = new HBox(12);
        row.getStyleClass().add("card");
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(12));

        Label name = new Label(title);
        name.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label price = new Label(priceText);
        price.setStyle("-fx-opacity: 0.85;");

        Label status = new Label();
        Button action = new Button("Buy");

        action.setOnAction(e -> {
            if (onBuy.run()) {
                status.setText("Purchased!");
                refreshBalance();
                game.rebuildAfterUpgrade();
                refreshList();
            } else {
                status.setText("Not enough credits");
            }
        });

        HBox spacer = new HBox();
        HBox.setHgrow(spacer, javafx.scene.layout.Priority.ALWAYS);

        row.getChildren().addAll(name, price, spacer, status, action);
        return row;
    }

    private void refreshList() {
        list.getChildren().clear();

        list.getChildren().add(
                upgradeRow("Add Reel",
                        upgradeData.getNextReelCost() + " cr",
                        () -> upgradeData.buyReel())
        );

        list.getChildren().add(
                upgradeRow("Add Row",
                        upgradeData.getNextRowCost() + " cr",
                        () -> upgradeData.buyRow())
        );

        list.getChildren().add(new Label(" "));

        for (SkinManager.Skin s : skinManager.all()) {
            list.getChildren().add(skinRow(s));
        }
    }

    public void refreshBalance() {
        balance.setText("BALANCE: " + model.getBalance());
    }

    public void setOnSkinEquipped(Runnable r) {
        this.onSkinEquipped = (r != null ? r : () -> {});
    }

    public BorderPane getRoot() {
        return root;
    }
}
