package app;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class AchievementsView {

    private final AchievementManager achievements;

    private final BorderPane root = new BorderPane();
    private final VBox list = new VBox(10);

    public void refreshAchievements() {
        refresh();
    }

    public AchievementsView(AchievementManager manager) {
        this.achievements = manager;

        VBox top = new VBox(6);
        top.setAlignment(Pos.CENTER);
        top.setPadding(new Insets(20));

        Label title = new Label("ACHIEVEMENTS");
        title.getStyleClass().add("title");

        top.getChildren().add(title);

        list.setPadding(new Insets(20));

        root.setTop(top);
        root.setCenter(list);

        refresh();
    }

    public void refresh() {
        list.getChildren().clear();

        for (Achievement a : achievements.all()) {

            HBox row = new HBox(12);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(12));
            row.getStyleClass().add("card");

            ImageView icon = new ImageView();
            try {
                Image img = new Image(getClass().getResourceAsStream(a.imagePath));
                icon.setImage(img);
            } catch (Exception ignored) {

                icon.setImage(new Image(getClass().getResourceAsStream("/achievements/blank.png")));
            }

            icon.setFitWidth(48);
            icon.setFitHeight(48);
            icon.setPreserveRatio(true);

            if (!a.isUnlocked()) {
                ColorAdjust gray = new ColorAdjust();
                gray.setSaturation(-1);
                gray.setBrightness(-0.2);
                icon.setEffect(gray);
            } else {
                icon.setEffect(null);
            }

            Label title = new Label(a.title);
            title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

            Label desc = new Label(a.description);
            desc.setStyle("-fx-opacity: 0.85;");

            Label status = new Label(
                    a.isUnlocked() ? "Unlocked" : "Locked"
            );
            status.setStyle("-fx-font-size: 16px;");

            HBox.setHgrow(desc, javafx.scene.layout.Priority.ALWAYS);

            row.getChildren().addAll(icon, title, desc, status);
            list.getChildren().add(row);
        }
    }

    public BorderPane getRoot() {
        return root;
    }
}
