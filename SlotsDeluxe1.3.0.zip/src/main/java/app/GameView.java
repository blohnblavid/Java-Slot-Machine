package app;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;

import java.util.*;

public class GameView {

    private final Model model;
    private final SkinManager skinManager;
    private final StatsManager stats;
    private final AchievementManager achievementManager;
    private final AchievementsView achievementsView;

    private final BorderPane root = new BorderPane();
    private final Label balance = new Label();
    private final Label status = new Label("Win the jackpot!");

    private final GridPane reelGrid = new GridPane();

    private final Spinner<Integer> betSpinner = new Spinner<>();
    private Button spinBtn;

    private final Image blankImage = new Image(getClass().getResourceAsStream("/images/blank.png"));
    private List<Image> symbolImages;
    private Timeline winBlink;

    public GameView(Model model,
                    SkinManager skinManager,
                    StatsManager stats,
                    AchievementManager achievementManager,
                    AchievementsView achievementsView) {

        this.model = model;
        this.skinManager = skinManager;
        this.stats = stats;
        this.achievementManager = achievementManager;
        this.achievementsView = achievementsView;

        build();
        rebuildGrid();

        symbolImages = model.symbols.stream()
                .map(s -> new Image(getClass().getResourceAsStream(s.imagePath)))
                .toList();

        refreshBalance();
        refreshSkin();
    }

    // -------------------- UI --------------------

    private ImageView reelImage() {
        ImageView iv = new ImageView(blankImage);
        iv.getStyleClass().add("reel");
        iv.setFitWidth(140);
        iv.setFitHeight(140);
        iv.setPreserveRatio(true);
        return iv;
    }

    private void rebuildGrid() {
        reelGrid.getChildren().clear();
        reelGrid.getColumnConstraints().clear();
        reelGrid.getRowConstraints().clear();
        reelGrid.setHgap(25);
        reelGrid.setVgap(25);
        reelGrid.setMaxWidth(700);
        reelGrid.setMaxHeight(700);
        reelGrid.setAlignment(Pos.CENTER);

        int rows = model.getRowCount();
        int cols = model.getReelCount();

        for (int r = 0; r < rows; r++) {
            reelGrid.getRowConstraints().add(new RowConstraints(130));
            for (int c = 0; c < cols; c++) {
                if (r == 0)
                    reelGrid.getColumnConstraints().add(new ColumnConstraints(130));

                reelGrid.add(reelImage(), c, r);
            }
        }
    }

    private ImageView getCell(int col, int row) {
        for (Node n : reelGrid.getChildren()) {
            Integer c = GridPane.getColumnIndex(n);
            Integer r = GridPane.getRowIndex(n);
            if (c != null && r != null && c == col && r == row)
                return (ImageView) n;
        }
        return null;
    }

    private void build() {
        root.getStyleClass().add("game-root");

        VBox top = new VBox(4);
        top.setAlignment(Pos.TOP_CENTER);
        top.setPadding(new Insets(16));

        Label title = new Label("Slots Deluxe");
        title.getStyleClass().add("title");

        balance.getStyleClass().add("balance");
        status.getStyleClass().add("status");

        top.getChildren().addAll(title, balance, status);

        VBox centerBox = new VBox(reelGrid);
        centerBox.setAlignment(Pos.TOP_CENTER);
        centerBox.setPadding(new Insets(0, 0, 0, 0));
        BorderPane.setMargin(centerBox, new Insets(130, 0, 0, 0));

        root.setCenter(centerBox);

        HBox controls = new HBox(12);
        controls.setAlignment(Pos.CENTER);
        controls.setPadding(new Insets(16));

        betSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 999, 10));

        spinBtn = new Button("SPIN");
        Button reset = new Button("RESET");
        Button applySkin = new Button("Reapply Skin");

        spinBtn.setOnAction(e -> onSpin());

        reset.setOnAction(e -> {
            model.resetBalance(200);
            status.setText("Balance reset.");
            refreshBalance();
        });

        applySkin.setOnAction(e -> refreshSkin());

        controls.getChildren().addAll(new Label("Bet:"), betSpinner, spinBtn, reset, applySkin);

        root.setTop(top);
        root.setBottom(controls);
    }

    // -------------------- Animation --------------------

    private void animateReels(List<Model.Symbol> outcome, boolean isWin, Runnable after) {
        if (winBlink != null) {
            winBlink.stop();
            reelGrid.getChildren().forEach(n -> n.setEffect(null));
        }

        int rows = model.getRowCount();
        int cols = model.getReelCount();
        Random rand = new Random();

        Timeline animation = new Timeline();

        for (int c = 0; c < cols; c++) {
            int baseDelay = c * 150;

            for (int r = 0; r < rows; r++) {
                ImageView iv = getCell(c, r);

                for (int i = 0; i < 10; i++) {
                    int delay = baseDelay + i * 50;
                    animation.getKeyFrames().add(new KeyFrame(
                            Duration.millis(delay),
                            e -> iv.setImage(symbolImages.get(rand.nextInt(symbolImages.size())))
                    ));
                }
            }
        }

        int finishTime = cols * 150 + 500;

        animation.getKeyFrames().add(new KeyFrame(Duration.millis(finishTime), e -> {
            int index = 0;

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    Model.Symbol s = outcome.get(index++);
                    getCell(c, r).setImage(new Image(getClass().getResourceAsStream(s.imagePath)));
                }
            }

            if (isWin) playWinBlink();
            if (after != null) after.run();
        }));

        animation.play();
    }

    private void playWinBlink() {
        List<DropShadow> effects = new ArrayList<>();

        for (Node n : reelGrid.getChildren()) {
            DropShadow ds = new DropShadow(0, Color.LAWNGREEN);
            n.setEffect(ds);
            effects.add(ds);
        }

        winBlink = new Timeline(
                new KeyFrame(Duration.millis(0), e -> effects.forEach(d -> d.setRadius(0))),
                new KeyFrame(Duration.millis(120), e -> effects.forEach(d -> d.setRadius(25))),
                new KeyFrame(Duration.millis(240), e -> effects.forEach(d -> d.setRadius(0)))
        );

        winBlink.setCycleCount(8);
        winBlink.play();
    }

    // -------------------- Spin Logic --------------------

    private void onSpin() {
        int bet = betSpinner.getValue();

        if (!model.bank.canBet(bet)) {
            status.setText("Insufficient credits!");
            return;
        }

        Model.SpinResult res = model.spin(bet);
        if (!res.accepted()) {
            status.setText("Bet not accepted.");
            return;
        }

        spinBtn.setDisable(true);

        animateReels(res.symbols(), res.win() > 0, () -> {

            int winAmt = res.win();

            if (stats != null)
                stats.recordSpin(bet, winAmt);

            if (winAmt > 0)
                status.setText("WIN +" + winAmt + "!");
            else
                status.setText("No win. Try again!");

            refreshBalance();

            // --------------------
            // ACHIEVEMENTS (after reels stop)
            // --------------------

            if (winAmt > 0) {
                achievementManager.unlock("first_spin");

                if (winAmt >= 1000)
                    achievementManager.unlock("big_win");

                if (winAmt >= 10000)
                    achievementManager.unlock("huge_win");

                if (winAmt >= 50000)
                    achievementManager.unlock("mega_win");
            }

            if (model.getBalance() >= 1_000_000)
                achievementManager.unlock("millionaire");

            achievementsView.refresh();

            spinBtn.setDisable(false);
        });
    }

    // -------------------- Utility --------------------

    public void rebuildAfterUpgrade() {
        rebuildGrid();
    }

    public void refreshBalance() {
        balance.setText("BALANCE: " + model.getBalance());
    }

    public void refreshSkin() {
        if (root.getScene() != null)
            skinManager.apply(root.getScene());
    }

    public BorderPane getRoot() {
        return root;
    }
}
