package app.themes;

public interface Theme {
    String name();
    String cssPath();
    String backgroundImage();
    String bgMusic();
    String spinSound();
    String winSound();
    int reelSize();
    int reelGap();
    int gridOffsetY();
    String titleFont();
    String titleColor();
    String glowColor();
    boolean useGlowEffects();

}

