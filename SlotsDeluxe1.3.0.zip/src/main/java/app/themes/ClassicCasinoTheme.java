package app.themes;

public class ClassicCasinoTheme implements Theme {

    @Override
    public String name() {
        return "Classic Casino";
    }

    @Override
    public String cssPath() {
        return "/themes/casino.css";
    }

    @Override
    public String backgroundImage() {
        // You can replace this later once you pick a background image
        return "/images/backgrounds/casino_red.png";
    }

    @Override
    public String bgMusic() {
        // Replace later with your own looped music track
        return "/music/casino_lounge.mp3";
    }

    @Override
    public String spinSound() {
        return "/sounds/spin_classic.wav";
    }

    @Override
    public String winSound() {
        return "/sounds/win_chime.wav";
    }

    @Override
    public int reelSize() {
        return 140;   // Good size for 1920x1080
    }

    @Override
    public int reelGap() {
        return 25;    // Space between symbols
    }

    @Override
    public int gridOffsetY() {
        return 140;   // Pushes the grid downward slightly under title
    }

    @Override
    public String titleFont() {
        return "/fonts/SHOWG.TTF";
    }

    @Override
    public String titleColor() {
        return "gold";   // Matches casino gold aesthetic
    }

    @Override
    public String glowColor() {
        return "gold";
    }

    @Override
    public boolean useGlowEffects() {
        return true;  // Allows neon-style glow on wins
    }
}

